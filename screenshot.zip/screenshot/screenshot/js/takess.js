console.log("Taking screenshot");
//function to download a UrlData and also accepts a name for the file
function downloadURI(uri, name) {

  var link = document.createElement("a");
  link.download = name;
  link.href = uri;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  delete link;
  chrome.downloads.setShelfEnabled(false);
}

// var cleardownloads = function(){
//     chrome.downloads.setShelfEnabled(false);
//     //chrome.downloads.setShelfEnabled(true);
//     chrome.downloads.erase({state: "complete"});
// };

function cleardownloads(){
    chrome.downloads.setShelfEnabled(false);
    //chrome.downloads.setShelfEnabled(true);
    chrome.downloads.erase({state: "complete"});
}




html2canvas(document.body).then(canvas => {
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var stamp = date + ',' + time
    var imgString = canvas.toDataURL("image/png");
    var url = imgString.replace(/^data:image\/[^;]+/, 'data:application/octet-stream');

    downloadURI( url, stamp+'.jpeg'); //Logging files in format YYYY-M-D,HH_MM_SS

    //cleardownloads();
});