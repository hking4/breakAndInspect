console.log("Taking screenshot");
//function to download a UrlData and also accepts a name for the file
function downloadURI(uri, name) {
  var link = document.createElement("a");
  link.download = name;
  link.href = uri;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  delete link;
}

html2canvas(document.body).then(canvas => {
    var imgString = canvas.toDataURL("image/png");
    var url = imgString.replace(/^data:image\/[^;]+/, 'data:application/octet-stream');
    downloadURI( url, "download.jpeg");
});